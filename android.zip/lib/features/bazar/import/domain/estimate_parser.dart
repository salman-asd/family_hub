import 'package:family_hub/core/utils/date_key.dart';
import 'package:family_hub/core/utils/money.dart';
import 'package:family_hub/core/utils/quantity.dart';
import 'package:family_hub/features/bazar/budgets/domain/budget.dart';
import 'package:family_hub/features/bazar/import/domain/bangla_quantity_parser.dart';
import 'package:family_hub/features/bazar/import/domain/category_mapping.dart';
import 'package:family_hub/features/bazar/import/domain/raw_sheet.dart';
import 'package:family_hub/features/bazar/import/domain/sheet_month.dart';
import 'package:family_hub/features/bazar/import/domain/text_cleaning.dart';

/// One estimate line the importer could not use, with why.
final class SkippedEstimateLine {
  const SkippedEstimateLine({
    required this.label,
    required this.reason,
    this.row,
  });

  final String label;

  /// A machine code: `no_amount` (an empty/bad amount), `no_category` (an
  /// unknown label the wizard must resolve).
  final String reason;

  /// 1-based spreadsheet row, when it came from a table.
  final int? row;

  @override
  bool operator ==(Object other) =>
      other is SkippedEstimateLine &&
      other.label == label &&
      other.reason == reason &&
      other.row == row;

  @override
  int get hashCode => Object.hash(label, reason, row);

  @override
  String toString() => 'SkippedEstimateLine($label, $reason, row $row)';
}

/// A budget plan read from a sheet, before the user confirms it.
final class BudgetDraft {
  BudgetDraft({
    required this.month,
    required Map<String, Money> categoryEstimates,
    required List<BudgetLine> lines,
    required List<SkippedEstimateLine> skipped,
  }) : categoryEstimates = Map<String, Money>.unmodifiable(categoryEstimates),
       lines = List<BudgetLine>.unmodifiable(lines),
       skipped = List<SkippedEstimateLine>.unmodifiable(skipped);

  /// The month the sheet title names; `null` when it could not be read.
  final MonthKey? month;

  final Map<String, Money> categoryEstimates;
  final List<BudgetLine> lines;
  final List<SkippedEstimateLine> skipped;

  /// Dry-grocery table total (the sum of its lines).
  Money get dryGroceriesTotal => Money.sum(lines.map((l) => l.estimate));

  /// Sum of the per-category estimates.
  Money get categoriesTotal => Money.sum(categoryEstimates.values);

  /// What the budget document stores as its total: the dry-grocery table when
  /// it has lines, otherwise the category estimates (P2-17's rule).
  Money get total =>
      lines.isEmpty ? categoriesTotal : dryGroceriesTotal + _nonDryBudget();

  /// The category estimates other than the dry-groceries one, which the table
  /// already covers.
  Money _nonDryBudget() => Money.sum([
    for (final entry in categoryEstimates.entries)
      if (entry.key != kDryGroceriesCategoryId) entry.value,
  ]);

  bool get isEmpty =>
      lines.isEmpty && categoryEstimates.isEmpty && skipped.isEmpty;

  @override
  String toString() =>
      'BudgetDraft($month, ${lines.length} lines, '
      '${categoryEstimates.length} categories, ${skipped.length} skipped)';
}

/// Column headers of the dry-grocery table (Appendix B.1).
const Set<String> _itemHeaders = <String>{'আইটেম', 'item'};
const Set<String> _budgetHeaders = <String>{'বাজেট', 'budget'};
const Set<String> _stockHeaders = <String>{'মজুদ', 'stock'};
const Set<String> _rateHeaders = <String>{'দর', 'rate'};
const Set<String> _totalHeaders = <String>{'মোট', 'total'};

/// The monthly-estimate block's title (`💹 মাসের সম্ভাব্য বাজার`).
const Set<String> _estimateTitles = <String>{
  'মাসের সম্ভাব্য বাজার',
  'monthly estimate',
};

/// The "other" sub-heading of that block (`💰 অন্যান্য`).
const Set<String> _otherHeading = <String>{'অন্যান্য', 'other'};

/// Reads both estimate blocks of a month sheet.
///
/// * the **dry-grocery table** (`আইটেম / বাজেট / মজুদ / দর / মোট`) becomes
///   budget lines; a line's total is the TYPED `মোট` (the workbook's formula is
///   never evaluated) or, without one, `quantity x rate`;
/// * the **monthly estimate block** becomes per-category estimates through the
///   same label table; fixed bills go to `cat_fixed_bills`, and a blank amount
///   (`ইলেক্ট্রিসিটি` in Oct-26) is listed as `no_amount`.
///
/// The month comes from the sheet's title cell (`"Oct 2026"`), falling back to
/// the sheet name (`Oct-26`).
BudgetDraft? parseEstimates(RawSheet sheet, {MonthKey? month}) {
  final lines = _dryGroceries(sheet);
  final estimates = _categoryEstimates(sheet);
  if (lines.lines.isEmpty &&
      estimates.categoryEstimates.isEmpty &&
      estimates.skipped.isEmpty &&
      lines.skipped.isEmpty) {
    return null;
  }
  return BudgetDraft(
    month: month ?? monthOfSheet(sheet),
    categoryEstimates: <String, Money>{
      if (lines.lines.isNotEmpty)
        kDryGroceriesCategoryId: Money.sum(
          lines.lines.map((l) => l.estimate),
        ),
      ...estimates.categoryEstimates,
    },
    lines: lines.lines,
    skipped: <SkippedEstimateLine>[...lines.skipped, ...estimates.skipped],
  );
}



/// Finds the header row of the dry-grocery table and reads its data rows.
({List<BudgetLine> lines, List<SkippedEstimateLine> skipped}) _dryGroceries(
  RawSheet sheet,
) {
  final header = _findHeaderRow(sheet);
  if (header == null) {
    return (lines: const <BudgetLine>[], skipped: const <SkippedEstimateLine>[]);
  }
  final lines = <BudgetLine>[];
  final skipped = <SkippedEstimateLine>[];
  final (row, item, budget, stock, rate, total) = header;

  for (var index = row + 1; index < sheet.rows.length; index++) {
    final nameText = sheet.cell(index, item);
    if (!(nameText is String) || cleanLabel(nameText).isEmpty) {
      // An empty item ends the table (the block below it has other columns).
      break;
    }
    final name = cleanLabel(nameText);
    final budgetText = _cellText(sheet.cell(index, budget));
    final rateText = _cellText(sheet.cell(index, rate));
    final totalText = _cellText(sheet.cell(index, total));
    final stockText = stock == null ? '' : _cellText(sheet.cell(index, stock));

    final qty = parseBanglaQuantity(budgetText);
    final rateValue = rateText.isEmpty ? null : Money.parse(rateText).valueOrNull;
    final typedTotal =
        totalText.isEmpty ? null : Money.parse(totalText).valueOrNull;

    final estimated = typedTotal ??
        (qty.qty != null && rateValue != null
            ? lineTotal(qty.qty!, rateValue)
            : null);
    if (estimated == null || estimated.isZero) {
      skipped.add(
        SkippedEstimateLine(
          label: name,
          reason: 'no_amount',
          row: index + 1,
        ),
      );
      continue;
    }
    lines.add(
      BudgetLine(
        name: name,
        plannedQty: qty.valueBased ? null : qty.qty,
        unit: qty.valueBased ? null : qty.unit,
        estimatedRate: rateValue,
        estimatedTotal: estimated,
        stock: stockText.isEmpty ? null : parseBanglaQuantity(stockText).qty,
      ),
    );
  }
  return (lines: lines, skipped: skipped);
}

/// `(header row, item, budget, stock, rate, total)` column indexes.
(int, int, int, int?, int?, int?)? _findHeaderRow(RawSheet sheet) {
  for (var row = 0; row < sheet.rows.length; row++) {
    final cells = sheet.rows[row];
    int? find(Set<String> words) {
      for (var i = 0; i < cells.length; i++) {
        final value = cells[i];
        if (value is String && words.contains(labelKey(value))) return i;
      }
      return null;
    }

    final item = find(_itemHeaders);
    final budget = find(_budgetHeaders);
    final total = find(_totalHeaders);
    if (item == null || budget == null || total == null) continue;
    return (row, item, budget, find(_stockHeaders), find(_rateHeaders), total);
  }
  return null;
}

/// The `label / amount` pairs of the monthly estimate block.
({Map<String, Money> categoryEstimates, List<SkippedEstimateLine> skipped})
_categoryEstimates(RawSheet sheet) {
  final estimates = <String, Money>{};
  final skipped = <SkippedEstimateLine>[];
  var inBlock = false;

  for (var index = 0; index < sheet.rows.length; index++) {
    final cells = sheet.rows[index];
    final labels = <String>[
      for (final cell in cells)
        if (cell is String && cleanLabel(cell).isNotEmpty) cleanLabel(cell),
    ];
    if (labels.any((l) => _estimateTitles.contains(labelKey(l)))) {
      inBlock = true;
      continue;
    }
    if (!inBlock) continue;
    // The block's leftmost label, and the first amount on the same row.
    final label = labels.isEmpty ? '' : labels.first;
    if (label.isEmpty) continue;
    if (_otherHeading.contains(labelKey(label))) continue;

    final rule = categoryRuleFor(label);
    if (rule == null) continue; // the block's own totals/notes, not a label
    final amount = _firstMoney(cells, after: _indexOfLabel(cells, label));
    if (amount == null) {
      skipped.add(
        SkippedEstimateLine(label: label, reason: 'no_amount', row: index + 1),
      );
      continue;
    }
    estimates[rule.categoryId] =
        (estimates[rule.categoryId] ?? Money.zero) + amount;
  }
  return (categoryEstimates: estimates, skipped: skipped);
}

int _indexOfLabel(List<Object?> cells, String label) {
  for (var i = 0; i < cells.length; i++) {
    final value = cells[i];
    if (value is String && cleanLabel(value) == label) return i;
  }
  return 0;
}

Money? _firstMoney(List<Object?> cells, {required int after}) {
  for (var i = after + 1; i < cells.length; i++) {
    final text = _cellText(cells[i]);
    if (text.isEmpty) continue;
    final parsed = Money.parse(text).valueOrNull;
    if (parsed != null && parsed.isNegative == false && !parsed.isZero) {
      return parsed;
    }
  }
  return null;
}

String _cellText(Object? value) => switch (value) {
  null => '',
  final String text => text.trim(),
  final num number => number.toString(),
  final DateTime date => DateKey(date.year, date.month, date.day).toString(),
  _ => value.toString().trim(),
};


