import 'package:family_hub/features/bazar/import/domain/text_cleaning.dart';

/// Where one spreadsheet category label belongs in the app catalog.
///
/// [categoryId] is a `cat_<seedKey>` id.  [itemId] is set only where the label
/// names ONE unambiguous catalog item (`পিয়াজ` -> onion, `আলু` -> potato);
/// generic labels (`বাজার`, `সবজি`, `মাছ`) never carry an item id, so they do
/// not pollute the catalog (Appendix B.2).
final class CategoryRule {
  const CategoryRule(this.categoryId, {this.itemId});

  final String categoryId;
  final String? itemId;

  @override
  bool operator ==(Object other) =>
      other is CategoryRule &&
      other.categoryId == categoryId &&
      other.itemId == itemId;

  @override
  int get hashCode => Object.hash(categoryId, itemId);

  @override
  String toString() => 'CategoryRule($categoryId, $itemId)';
}

/// Fixed-bill item ids the estimate block refers to (Appendix B.3).
const String kItemFlatRent = 'item_flat_rent';
const String kItemElectricity = 'item_electricity';
const String kItemInternet = 'item_internet';
const String kItemGarbage = 'item_garbage';
const String kCategoryFixedBills = 'cat_fixed_bills';

/// The workbook's labels (normalized through [labelKey]) -> app category.
const Map<String, CategoryRule> _rules = <String, CategoryRule>{
  // Expense block labels (column C).
  'সবজি': CategoryRule('cat_vegetables'),
  'পিয়াজ': CategoryRule('cat_vegetables', itemId: 'item_onion'),
  'পেঁয়াজ': CategoryRule('cat_vegetables', itemId: 'item_onion'),
  'আলু': CategoryRule('cat_vegetables', itemId: 'item_potato'),
  'মাছ': CategoryRule('cat_fish'),
  'ফল': CategoryRule('cat_fruits'),
  'গরুর গোস্ত': CategoryRule('cat_beef'),
  'গরুর মাংস': CategoryRule('cat_beef'),
  'মুরগীর মাংস': CategoryRule('cat_chicken'),
  'মুরগির মাংস': CategoryRule('cat_chicken'),
  'ডিম': CategoryRule('cat_eggs'),
  'শুকনা বাজার': CategoryRule('cat_dry_groceries'),
  'গ্যাস': CategoryRule('cat_gas'),
  'মা এর ঔষধ': CategoryRule('cat_medicine'),
  'ঔষধ': CategoryRule('cat_medicine'),
  'অন্যান্য': CategoryRule('cat_other'),
  // Estimate block labels (column M/N).
  'কাচা বাজার': CategoryRule('cat_vegetables'),
  'কাঁচা বাজার': CategoryRule('cat_vegetables'),
  'শুকনো বাজার': CategoryRule('cat_dry_groceries'),
  'ফ্লাট ভাড়া': CategoryRule(kCategoryFixedBills, itemId: kItemFlatRent),
  'ইলেক্ট্রিসিটি': CategoryRule(kCategoryFixedBills, itemId: kItemElectricity),
  'ইলেকট্রিসিটি': CategoryRule(kCategoryFixedBills, itemId: kItemElectricity),
  'ইন্টারনেট': CategoryRule(kCategoryFixedBills, itemId: kItemInternet),
  'ময়লার বিল': CategoryRule(kCategoryFixedBills, itemId: kItemGarbage),
};

/// The rule for a raw category cell, or `null` when the label is unknown.
///
/// An unknown label becomes an `UnresolvedCategory` in the wizard, never a
/// silent guess.
CategoryRule? categoryRuleFor(String label) => _rules[labelKey(label)];

/// Every known label (used by tests and by the wizard's suggestions).
List<String> knownCategoryLabels() => _rules.keys.toList()..sort();
