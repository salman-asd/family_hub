import 'package:family_hub/core/utils/date_key.dart';
import 'package:family_hub/features/bazar/import/domain/raw_sheet.dart';

/// The month a sheet is about, or `null` when it cannot be read.
///
/// The title cell wins (`"Oct 2026"`, `"Sept 2026"`); otherwise the sheet name
/// is read (`Oct-26` -> 2026-10).  A template sheet yields `null`.
MonthKey? monthOfSheet(RawSheet sheet) =>
    _monthFromTitle(sheet) ?? monthKeyOfSheetName(sheet.name);

/// `Oct-26` -> `2026-10`; a non-month sheet name -> `null`.
MonthKey? monthKeyOfSheetName(String name) {
  final parsed = monthOfSheetName(name);
  return parsed == null ? null : MonthKey(parsed.$1, parsed.$2);
}

final RegExp _title = RegExp(
  r'(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*[\s,/-]+(\d{4})',
  caseSensitive: false,
);

const List<String> _months = <String>[
  'jan', 'feb', 'mar', 'apr', 'may', 'jun',
  'jul', 'aug', 'sep', 'oct', 'nov', 'dec',
];

MonthKey? _monthFromTitle(RawSheet sheet) {
  for (final row in sheet.rows) {
    for (final cell in row) {
      if (cell is! String) continue;
      final match = _title.firstMatch(cell);
      if (match == null) continue;
      final index = _months.indexOf(
        match.group(1)!.toLowerCase().substring(0, 3),
      );
      if (index < 0) continue;
      return MonthKey(int.parse(match.group(2)!), index + 1);
    }
  }
  return null;
}
