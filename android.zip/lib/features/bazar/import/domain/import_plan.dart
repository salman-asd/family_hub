import 'package:family_hub/core/utils/date_key.dart';
import 'package:family_hub/core/utils/date_key.dart';
import 'package:family_hub/core/utils/money.dart';
import 'package:family_hub/features/bazar/import/domain/estimate_parser.dart';
import 'package:family_hub/features/bazar/import/domain/expense_row_parser.dart';
import 'package:family_hub/features/bazar/import/domain/import_row_issue.dart';

/// What will happen to one spreadsheet row.
enum RowResolution {
  /// The label mapped to a catalog category as-is.
  asIs,

  /// The user picked a category for an unknown label.
  mapTo,

  /// The user asked for a NEW category with this label.
  createCategory,

  /// The user dropped the row.
  skip,
}

/// One row of the plan: the parsed row plus the user's decision.
final class ImportRow {
  const ImportRow({
    required this.parsed,
    required this.resolution,
    this.categoryId,
    this.itemId,
  });

  final ParsedExpenseRow parsed;
  final RowResolution resolution;

  /// The category it will be saved under (`null` only when skipped).
  final String? categoryId;

  /// A catalog item id, set only on an exact item match (Appendix B.2).
  final String? itemId;

  ImportRow copyWith({
    RowResolution? resolution,
    String? categoryId,
    String? itemId,
    bool clearItemId = false,
  }) => ImportRow(
    parsed: parsed,
    resolution: resolution ?? this.resolution,
    categoryId: categoryId ?? this.categoryId,
    itemId: clearItemId ? null : (itemId ?? this.itemId),
  );

  bool get isSkipped => resolution == RowResolution.skip;
}

/// The whole import plan, before anything is written.
final class ImportPlan {
  ImportPlan({
    required List<ImportRow> rows,
    required Map<MonthKey, int> rowCountByMonth,
    required this.budget,
    required List<SkippedLine> skipped,
    required this.report,
    required List<String> unresolvedLabels,
  }) : rows = List<ImportRow>.unmodifiable(rows),
       rowCountByMonth = Map<MonthKey, int>.unmodifiable(rowCountByMonth),
       skipped = List<SkippedLine>.unmodifiable(skipped),
       unresolvedLabels = List<String>.unmodifiable(unresolvedLabels);

  final List<ImportRow> rows;
  final Map<MonthKey, int> rowCountByMonth;
  final BudgetDraft? budget;
  final List<SkippedLine> skipped;
  final ImportReport report;

  /// Labels the label table did not know: the wizard must map them.
  final List<String> unresolvedLabels;

  Iterable<ImportRow> get importable => rows.where((r) => !r.isSkipped);

  /// `true` while at least one unknown label has no decision yet.
  bool get needsAttention => importable.any(
    (row) => row.categoryId == null &&
        row.resolution != RowResolution.skip,
  );

  ImportPlan withRows(List<ImportRow> next) => ImportPlan(
    rows: next,
    rowCountByMonth: rowCountByMonth,
    budget: budget,
    skipped: skipped,
    report: report,
    unresolvedLabels: unresolvedLabels,
  );
}

/// A line that will not be imported, with why (machine code).
final class SkippedLine {
  const SkippedLine({required this.label, required this.reason, this.row});

  final String label;
  final String reason;
  final int? row;

  @override
  String toString() => 'SkippedLine($label, $reason, row $row)';
}

/// The reconciliation numbers shown before the user confirms.
final class ImportReport {
  ImportReport({
    required Map<String, Money> sheetTotalsByLabel,
    required Map<String, Money> importTotalsByCategory,
    required Money sheetTotal,
    required Money importTotal,
    required List<ImportRowIssue> issues,
    required this.skippedRows,
  }) : sheetTotalsByLabel = Map<String, Money>.unmodifiable(
         sheetTotalsByLabel,
       ),
       importTotalsByCategory = Map<String, Money>.unmodifiable(
         importTotalsByCategory,
       ),
       issues = List<ImportRowIssue>.unmodifiable(issues);

  /// Sum per spreadsheet label, always from EVERY priced row.
  final Map<String, Money> sheetTotalsByLabel;

  /// Sum per app category, from the rows that will actually be imported.
  final Map<String, Money> importTotalsByCategory;

  /// The sheet's own total (all priced rows).
  final Money sheetTotal;

  /// What the app will hold afterwards for the selected months.
  final Money importTotal;

  final List<ImportRowIssue> issues;

  /// Rows skipped because their price was empty or `0`.
  final int skippedRows;

  /// `true` when the two totals agree: nothing was dropped.
  bool get reconciles => sheetTotal == importTotal;

  Money get difference => importTotal - sheetTotal;
}
