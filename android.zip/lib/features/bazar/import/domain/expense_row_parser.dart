import 'package:family_hub/core/utils/bangla_numerals.dart';
import 'package:family_hub/core/utils/date_key.dart';
import 'package:family_hub/core/utils/money.dart';
import 'package:family_hub/features/bazar/import/domain/column_mapping.dart';
import 'package:family_hub/features/bazar/import/domain/import_row_issue.dart';
import 'package:family_hub/features/bazar/import/domain/raw_sheet.dart';
import 'package:family_hub/features/bazar/import/domain/text_cleaning.dart';

/// One priced row, before the category is resolved.
final class ParsedExpenseRow {
  const ParsedExpenseRow({
    required this.row,
    required this.dateKey,
    required this.itemName,
    required this.categoryLabel,
    required this.amount,
  });

  /// 1-based spreadsheet row (for the issue list).
  final int row;
  final DateKey dateKey;

  /// Cleaned free text from the item cell; may be empty.
  final String itemName;

  /// Cleaned label from the category cell; may be empty.
  final String categoryLabel;

  final Money amount;

  @override
  String toString() =>
      'ParsedExpenseRow($row, $dateKey, $categoryLabel, $amount)';
}

/// Everything the expense block yielded.
final class ParsedRows {
  ParsedRows({
    required List<ParsedExpenseRow> rows,
    required List<ImportRowIssue> issues,
    required this.skippedBlankAmounts,
  }) : rows = List<ParsedExpenseRow>.unmodifiable(rows),
       issues = List<ImportRowIssue>.unmodifiable(issues);

  final List<ParsedExpenseRow> rows;
  final List<ImportRowIssue> issues;

  /// Rows that were ignored because the price cell was empty or `0` (the
  /// workbook has `0` placeholders): not an error, just not spending.
  final int skippedBlankAmounts;
}

/// Reads the `Date / Item / Category / Price` block of one sheet.
///
/// Rules taken from the real workbook (Appendix B.1):
/// * **date carry-forward**: the date is written only on the first row of a
///   day, so a blank date cell inherits the previous non-blank one;
/// * a row whose amount is empty or `0` is SKIPPED (a placeholder), not an
///   error;
/// * a row with no item and no category is a spacer (the workbook is 137 rows
///   tall but has ~59 entries): it is skipped silently;
/// * a bad date, a bad amount, a missing category/item or a future date is
///   COLLECTED as an issue and the row is dropped;
/// * formulas never reach here (`xlsx_workbook_reader` drops them).
ParsedRows parseExpenseRows(
  RawSheet sheet,
  ColumnMapping mapping, {
  int firstDataRow = 0,
  DateKey? today,
}) {
  final rows = <ParsedExpenseRow>[];
  final issues = <ImportRowIssue>[];
  var skippedBlank = 0;
  DateKey? carried;
  final first = firstDataRow > 0 ? firstDataRow : mapping.headerRow + 1;

  for (var index = first; index < sheet.rows.length; index++) {
    final sheetRow = index + 1;
    final dateCell = sheet.cell(index, mapping.date);
    final itemText = _text(sheet.cell(index, mapping.item));
    final categoryText = _text(sheet.cell(index, mapping.category));
    final amountText = _text(sheet.cell(index, mapping.amount));

    if (_isBlank(dateCell) &&
        itemText.isEmpty &&
        categoryText.isEmpty &&
        amountText.isEmpty) {
      continue; // a spacer row
    }

    var date = carried;
    if (!_isBlank(dateCell)) {
      final parsed = parseSheetDate(dateCell);
      if (parsed == null) {
        issues.add(
          ImportRowIssue(
            row: sheetRow,
            reason: ImportRowIssueReason.badDate,
            value: dateCell.toString(),
          ),
        );
        continue;
      }
      date = parsed;
      carried = parsed;
    }
    if (date == null) {
      issues.add(
        ImportRowIssue(
          row: sheetRow,
          reason: ImportRowIssueReason.badDate,
          value: dateCell?.toString(),
        ),
      );
      continue;
    }

    if (amountText.isEmpty) {
      skippedBlank++;
      continue;
    }
    final amount = Money.parse(amountText);
    final value = amount.valueOrNull;
    if (value == null) {
      issues.add(
        ImportRowIssue(
          row: sheetRow,
          reason: ImportRowIssueReason.badAmount,
          value: amountText,
        ),
      );
      continue;
    }
    if (value.isZero) {
      skippedBlank++;
      continue;
    }
    if (value.isNegative) {
      issues.add(
        ImportRowIssue(
          row: sheetRow,
          reason: ImportRowIssueReason.badAmount,
          value: amountText,
        ),
      );
      continue;
    }
    if (today != null && date.isAfter(today)) {
      issues.add(
        ImportRowIssue(
          row: sheetRow,
          reason: ImportRowIssueReason.futureDate,
          value: date.toString(),
        ),
      );
      continue;
    }

    final category = cleanLabel(categoryText);
    final item = cleanLabel(itemText);
    if (category.isEmpty) {
      issues.add(
        ImportRowIssue(
          row: sheetRow,
          reason: ImportRowIssueReason.noCategory,
          value: item,
        ),
      );
      continue;
    }

    rows.add(
      ParsedExpenseRow(
        row: sheetRow,
        dateKey: date,
        itemName: item,
        categoryLabel: category,
        amount: value,
      ),
    );
  }

  return ParsedRows(
    rows: rows,
    issues: issues,
    skippedBlankAmounts: skippedBlank,
  );
}

/// A cell as trimmed text; a number keeps its decimal form (the adapter does
/// that), and a real date cell becomes `yyyy-MM-dd`.
String _text(Object? value) => switch (value) {
  null => '',
  final String text => text.trim(),
  final DateTime date => DateKey(date.year, date.month, date.day).toString(),
  final num number => number.toString(),
  _ => value.toString().trim(),
};

bool _isBlank(Object? value) =>
    value == null || (value is String && value.trim().isEmpty);

/// Reads the many date shapes a spreadsheet produces.
///
/// `DateTime` is used as it is; text is accepted as `yyyy-MM-dd`,
/// `dd/MM/yyyy`, `d-M-yy`/`d-M-yyyy` (the workbook's `d-mmm-yy`) with English
/// month names or numbers, and Bangla digits (via `toEnglishDigits`).  Anything
/// else is `null` (reported as `badDate`), never an exception.
DateKey? parseSheetDate(Object? value) {
  if (value is DateTime) return DateKey(value.year, value.month, value.day);
  if (value is! String) return null;
  final text = toEnglishDigits(value).trim();
  if (text.isEmpty) return null;

  final iso = DateKey.parse(text).valueOrNull;
  if (iso != null) return iso;

  final numeric = RegExp(r'^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2,4})$')
      .firstMatch(text);
  if (numeric != null) {
    final day = int.parse(numeric.group(1)!);
    final month = int.parse(numeric.group(2)!);
    final year = _year(numeric.group(3)!);
    return _safeDate(year, month, day);
  }

  final named = RegExp(r'^(\d{1,2})[ \-]([A-Za-z]{3,9})[ \-](\d{2,4})$')
      .firstMatch(text);
  if (named != null) {
    final day = int.parse(named.group(1)!);
    final month = _monthNumber(named.group(2)!);
    final year = _year(named.group(3)!);
    if (month == null) return null;
    return _safeDate(year, month, day);
  }

  return null;
}

int _year(String raw) {
  final value = int.parse(raw);
  if (raw.length <= 2) return value >= 70 ? 1900 + value : 2000 + value;
  return value;
}

int? _monthNumber(String raw) {
  const names = <String>[
    'jan', 'feb', 'mar', 'apr', 'may', 'jun',
    'jul', 'aug', 'sep', 'oct', 'nov', 'dec',
  ];
  final key = raw.toLowerCase();
  for (var i = 0; i < names.length; i++) {
    if (key.startsWith(names[i])) return i + 1;
  }
  return null;
}

DateKey? _safeDate(int year, int month, int day) {
  if (year < 1 || year > 9999 || month < 1 || month > 12 || day < 1) {
    return null;
  }
  final check = DateTime.utc(year, month, day);
  if (check.year != year || check.month != month || check.day != day) {
    return null;
  }
  return DateKey(year, month, day);
}
