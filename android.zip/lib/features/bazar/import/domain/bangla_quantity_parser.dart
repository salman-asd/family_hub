import 'package:family_hub/core/utils/bangla_numerals.dart';
import 'package:family_hub/core/utils/quantity.dart';
import 'package:family_hub/core/utils/unit_catalog.dart';

/// What a quantity cell in the dry-grocery table says.
///
/// `valueBased` marks `১০০ টাকার` ("৳100 worth"): a purchase worth that much,
/// with NO quantity — the budget line then keeps only its rate/total.
final class ParsedQty {
  const ParsedQty({
    required this.raw,
    this.qty,
    this.unit,
    this.valueBased = false,
  });

  final String raw;
  final Quantity? qty;
  final Unit? unit;
  final bool valueBased;

  bool get isQuantity => qty != null;

  @override
  String toString() =>
      'ParsedQty($raw, ${qty?.milli}, ${unit?.name}, valueBased: $valueBased)';
}

final int _scale = 1000; // milli-units

/// Parses `৫০ কেজি`, `১/২ কেজি`, `১ ১/২ কেজি`, `৩ লিটার`, `২ ডজন`,
/// `১০০ টাকার` (Bangla or English digits).
///
/// Integer arithmetic only: a fraction is scaled by [denominator] and rounded
/// half-up to milli-units, so `১/৩` never becomes a repeating decimal.
ParsedQty parseBanglaQuantity(String raw) {
  final text = toEnglishDigits(raw)
      .replaceAll('\u00A0', ' ')
      .replaceAll(',', '')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
  if (text.isEmpty) return ParsedQty(raw: raw);

  if (text.endsWith('টাকার') || text.endsWith('টাকা')) {
    return ParsedQty(raw: raw, valueBased: true);
  }

  final match = RegExp(
    r'^(\d+)?(?:\s*(\d+)\s*/\s*(\d+))?\s*([\p{L}]+)?$',
    unicode: true,
  ).firstMatch(text);
  if (match == null) return ParsedQty(raw: raw);

  final whole = int.tryParse(match.group(1) ?? '') ?? 0;
  final numerator = int.tryParse(match.group(2) ?? '');
  final denominator = int.tryParse(match.group(3) ?? '');
  final unit = parseUnit(match.group(4) ?? '');

  var milli = whole * _scale;
  if (numerator != null && denominator != null && denominator > 0) {
    // half-up to the milli-unit: (numerator * 1000 + d/2) ~/ d
    milli += (numerator * _scale + denominator ~/ 2) ~/ denominator;
  }
  if (milli <= 0) return ParsedQty(raw: raw, unit: unit);

  return ParsedQty(
    raw: raw,
    qty: Quantity.milli(milli),
    unit: unit,
  );
}
