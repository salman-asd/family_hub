import 'package:family_hub/features/bazar/items_categories/domain/text_normalizer.dart';

/// Leading/trailing emoji, symbols and variation selectors a spreadsheet label
/// carries.  It strips anything that is not a letter, digit or space from BOTH
/// ends, so `"🧅 পিয়াজ  "` -> `"পিয়াজ"` and `"💹 মাসের সম্ভাব্য বাজার"` ->
/// `"মাসের সম্ভাব্য বাজার"`.
final RegExp _edgeSymbols = RegExp(
  r'^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$',
  unicode: true,
);

final RegExp _multiSpace = RegExp(r'\s+');

/// Strips emoji/symbols from the ends and collapses spaces.
///
/// The result is NOT lower-cased (a label is shown to the user).  Match labels
/// through [labelKey], which also composes the nukta pairs and normalises
/// digits, so `পিয়াজ` and `পিয়াজ ` agree.
String cleanLabel(String value) {
  final trimmed = value.replaceAll(_edgeSymbols, '').replaceAll(_multiSpace, ' ');
  return trimmed.trim();
}

/// The comparison key of a label: [cleanLabel] + [normalizeSearch].
///
/// `normalizeSearch` already drops zero-width joiners and composes the nukta
/// pairs, so there is one normaliser in the app.
String labelKey(String value) => normalizeSearch(cleanLabel(value));
