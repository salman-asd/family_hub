/// One worksheet as the importer sees it: neutral cell values only.
///
/// The file adapter (`xlsx_workbook_reader.dart`) converts every numeric cell
/// to its DECIMAL STRING immediately, so no money arithmetic ever happens in a
/// float.  A cell is one of:
///
/// * `null` (empty),
/// * [String] (text, a number written in decimal, an already-formatted date),
/// * [int] (rare; kept as `int` by some writers),
/// * [DateTime] (a real date cell).
///
/// Nothing in `domain/` ever imports `excel`.
final class RawSheet {
  const RawSheet({required this.name, required this.rows});

  final String name;
  final List<List<Object?>> rows;

  /// The cell at ([row], [column]), or `null` when the sheet is too short.
  ///
  /// Rows and columns are 0-based here; the parser adds the workbook's own
  /// 1-based numbering (Appendix B talks in spreadsheet rows).
  Object? cell(int row, int column) {
    if (row < 0 || row >= rows.length) return null;
    final line = rows[row];
    if (column < 0 || column >= line.length) return null;
    return line[column];
  }

  @override
  String toString() => 'RawSheet($name, ${rows.length} rows)';
}

/// The sheet name of a month sheet: `Oct-26`, `Sept-26`, `Aug-26`, `Template`.
///
/// A month sheet is `<Mon|Month>-yy`; the template sheets match neither, which
/// is how the importer skips them (Appendix B.1).
final RegExp _monthSheet = RegExp(
  r'^(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*-(\d{2,4})$',
  caseSensitive: false,
);

const Map<String, int> _monthNumbers = <String, int>{
  'jan': 1,
  'feb': 2,
  'mar': 3,
  'apr': 4,
  'may': 5,
  'jun': 6,
  'jul': 7,
  'aug': 8,
  'sep': 9,
  'sept': 9,
  'oct': 10,
  'nov': 11,
  'dec': 12,
};

/// The month a sheet name implies, or `null` for a template/other sheet.
///
/// A 2-digit year is read as 20yy (the workbook's own range, 2026-…).
(int year, int month)? monthOfSheetName(String name) {
  final match = _monthSheet.firstMatch(name.trim());
  if (match == null) return null;
  final month = _monthNumbers[match.group(1)!.toLowerCase()];
  final rawYear = int.parse(match.group(2)!);
  if (month == null) return null;
  return (rawYear < 100 ? 2000 + rawYear : rawYear, month);
}
