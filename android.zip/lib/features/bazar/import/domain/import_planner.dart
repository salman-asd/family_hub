import 'package:family_hub/core/utils/date_key.dart';
import 'package:family_hub/core/utils/money.dart';
import 'package:family_hub/features/bazar/import/domain/category_mapping.dart';
import 'package:family_hub/features/bazar/import/domain/column_mapping.dart';
import 'package:family_hub/features/bazar/import/domain/estimate_parser.dart';
import 'package:family_hub/features/bazar/import/domain/expense_row_parser.dart';
import 'package:family_hub/features/bazar/import/domain/import_plan.dart';
import 'package:family_hub/features/bazar/import/domain/import_row_issue.dart';
import 'package:family_hub/features/bazar/import/domain/raw_sheet.dart';
import 'package:family_hub/features/bazar/import/domain/text_cleaning.dart';

/// Builds the plan for one sheet: every priced row resolved as far as possible,
/// plus the reconciliation a user checks before confirming.
///
/// Resolution rules (Appendix B.2/B.4):
/// * a known label maps to its category; the item is linked only on an EXACT
///   catalog match, so `বাজার` stays free text;
/// * an unknown label stays UNRESOLVED (`categoryId == null`) for the wizard,
///   and is listed in `unresolvedLabels`;
/// * nothing is written here: this is pure.
ImportPlan planExpenseImport({
  required RawSheet sheet,
  ColumnMapping? mapping,
  Iterable<CatalogItemLike> catalogItems = const <CatalogItemLike>[],
  DateKey? today,
  BudgetDraft? budget,
}) {
  final columns = mapping ?? suggest(sheet);
  final itemIndex = CatalogItemLookup(catalogItems);

  final parsed = columns == null
      ? ParsedRows(
          rows: const <ParsedExpenseRow>[],
          issues: const <ImportRowIssue>[],
          skippedBlankAmounts: 0,
        )
      : parseExpenseRows(sheet, columns, today: today);

  final rows = <ImportRow>[];
  final sheetTotals = <String, Money>{};
  final unresolved = <String>[];

  for (final row in parsed.rows) {
    sheetTotals[row.categoryLabel] =
        (sheetTotals[row.categoryLabel] ?? Money.zero) + row.amount;
    final rule = categoryRuleFor(row.categoryLabel);
    if (rule == null) {
      unresolved.add(row.categoryLabel);
      rows.add(
        ImportRow(
          parsed: row,
          resolution: RowResolution.skip,
          itemId: itemIndex.exactItemId(row.itemName),
        ),
      );
      continue;
    }
    rows.add(
      ImportRow(
        parsed: row,
        resolution: RowResolution.asIs,
        categoryId: rule.categoryId,
        itemId: itemIndex.exactItemId(row.itemName) ?? rule.itemId,
      ),
    );
  }

  final importTotals = <String, Money>{};
  final counts = <MonthKey, int>{};
  for (final row in rows) {
    final category = row.categoryId;
    if (category == null) continue;
    importTotals[category] = (importTotals[category] ?? Money.zero) + row.parsed.amount;
    final month = row.parsed.dateKey.monthKey;
    counts[month] = (counts[month] ?? 0) + 1;
  }

  return ImportPlan(
    rows: rows,
    rowCountByMonth: counts,
    budget: budget ?? parseEstimates(sheet),
    skipped: const <SkippedLine>[],
    unresolvedLabels: <String>{...unresolved}.toList()..sort(),
    report: ImportReport(
      sheetTotalsByLabel: sheetTotals,
      importTotalsByCategory: importTotals,
      sheetTotal: Money.sum(sheetTotals.values),
      importTotal: Money.sum(importTotals.values),
      issues: parsed.issues,
      skippedRows: parsed.skippedBlankAmounts,
    ),
  );
}

/// The two fields matching needs, so `domain/` never imports the catalog
/// entity (which is fine too, but keeps this file testable on its own).
final class CatalogItemLike {
  const CatalogItemLike({required this.id, required this.names});

  final String id;

  /// Every name the item answers to (Bangla, English, aliases), raw.
  final List<String> names;
}

/// Exact-name lookup: only a row whose item cell EQUALS a catalog name (after
/// normalising) links an item, so `বাজার` or `সবজি` never become catalog items.
final class CatalogItemLookup {
  CatalogItemLookup(Iterable<CatalogItemLike> items) {
    for (final item in items) {
      for (final name in item.names) {
        final key = labelKey(name);
        if (key.isEmpty) continue;
        _byName.putIfAbsent(key, () => item.id);
      }
    }
  }

  final Map<String, String> _byName = <String, String>{};

  String? exactItemId(String itemName) {
    final key = labelKey(itemName);
    if (key.isEmpty) return null;
    return _byName[key];
  }
}
