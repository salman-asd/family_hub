/// Why one spreadsheet row could not become an expense.
///
/// Issues are COLLECTED, never thrown: a bad row is reported to the user and
/// the rest of the file still imports (P2-26).
enum ImportRowIssueReason {
  badDate,
  badAmount,
  noCategory,
  noItem,
  futureDate,
  duplicate,
}

/// One bad row: where it is (1-based, as the spreadsheet shows it) and why.
final class ImportRowIssue {
  const ImportRowIssue({
    required this.row,
    required this.reason,
    this.value,
  });

  /// 1-based spreadsheet row.
  final int row;
  final ImportRowIssueReason reason;

  /// The offending cell text, for the "fix this row" list.  Never user copy:
  /// the screen localises [reason].
  final String? value;

  @override
  bool operator ==(Object other) =>
      other is ImportRowIssue &&
      other.row == row &&
      other.reason == reason &&
      other.value == value;

  @override
  int get hashCode => Object.hash(row, reason, value);

  @override
  String toString() => 'ImportRowIssue(row $row, ${reason.name}, $value)';
}
