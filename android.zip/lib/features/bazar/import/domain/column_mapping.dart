import 'package:family_hub/features/bazar/import/domain/raw_sheet.dart';
import 'package:family_hub/features/bazar/import/domain/text_cleaning.dart';

/// Which sheet column holds what (0-based indexes).
final class ColumnMapping {
  const ColumnMapping({
    required this.date,
    required this.item,
    required this.category,
    required this.amount,
    required this.headerRow,
  });

  final int date;
  final int item;
  final int category;
  final int amount;

  /// 0-based index of the header row the mapping came from.
  final int headerRow;

  /// 1-based, the way a spreadsheet shows it ("header row 5").
  int get headerRowNumber => headerRow + 1;

  @override
  bool operator ==(Object other) =>
      other is ColumnMapping &&
      other.date == date &&
      other.item == item &&
      other.category == category &&
      other.amount == amount &&
      other.headerRow == headerRow;

  @override
  int get hashCode => Object.hash(date, item, category, amount, headerRow);

  @override
  String toString() =>
      'ColumnMapping(date: $date, item: $item, category: $category, '
      'amount: $amount, header: $headerRowNumber)';
}

/// Header words, compared through [labelKey] (case, spacing, digits ignored).
const Set<String> _dateWords = <String>{
  'date',
  'তারিখ',
  'দিন',
  'day',
};

const Set<String> _itemWords = <String>{
  'item',
  'items',
  'আইটেম',
  'পণ্য',
  'বাজার',
  'বিবরণ',
  'description',
};

const Set<String> _categoryWords = <String>{
  'category',
  'ক্যাটেগরি',
  'ক্যাটাগরি',
  'খাত',
  'ধরন',
};

const Set<String> _amountWords = <String>{
  'price',
  'amount',
  'দাম',
  'টাকা',
  'মূল্য',
  'খরচ',
  'total',
};

/// The first [maxScan] rows: enough for a title block above the header.
const int kHeaderScanRows = 30;

/// Finds the header row and its four columns, or `null` when the sheet has no
/// recognisable header.
///
/// `Bazar.xlsx` puts the header on row 5 (columns A–D) under a title block, so
/// the first [kHeaderScanRows] rows are searched.  A row only counts when it
/// names at least the date AND the amount; a partially recognised row fills
/// the rest from the rows around it when possible.
ColumnMapping? suggest(RawSheet sheet) {
  final limit = sheet.rows.length < kHeaderScanRows
      ? sheet.rows.length
      : kHeaderScanRows;
  for (var row = 0; row < limit; row++) {
    final mapping = _mappingAt(sheet, row);
    if (mapping != null) return mapping;
  }
  return null;
}

ColumnMapping? _mappingAt(RawSheet sheet, int row) {
  final cells = sheet.rows[row];
  final date = _columnOf(cells, _dateWords);
  final amount = _columnOf(cells, _amountWords);
  if (date == null || amount == null) return null;
  final item = _columnOf(cells, _itemWords);
  final category = _columnOf(cells, _categoryWords);
  return ColumnMapping(
    date: date,
    item: item ?? _firstFree(<int?>{date, amount, category}),
    category: category ?? _firstFree(<int?>{date, amount, item}),
    amount: amount,
    headerRow: row,
  );
}

int? _columnOf(List<Object?> cells, Set<String> words) {
  for (var i = 0; i < cells.length; i++) {
    final value = cells[i];
    if (value is! String) continue;
    final key = labelKey(value);
    if (key.isEmpty) continue;
    if (words.contains(key)) return i;
  }
  return null;
}

/// The first column (A, B, C …) not already used, so a sheet with only
/// `Date`/`Price` still maps item and category to distinct columns.
int _firstFree(Set<int?> used) {
  for (var i = 0; i < 26; i++) {
    if (!used.contains(i)) return i;
  }
  return 0;
}
