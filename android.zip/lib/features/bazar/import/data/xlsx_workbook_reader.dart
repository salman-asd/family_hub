import 'dart:typed_data';

import 'package:excel/excel.dart';
import 'package:family_hub/features/bazar/import/domain/raw_sheet.dart';
import 'package:flutter/painting.dart' show TextSpan;

/// The ONE place the app touches the `excel` package (P2-26).
///
/// Conversions, so no float ever reaches the domain:
/// * a number cell becomes its DECIMAL STRING (`IntCellValue.value.toString()`,
///   `DoubleCellValue.value.toString()`), never a `double` handed on;
/// * a date/time cell becomes a `DateTime` (the parser formats the `dateKey`);
/// * a **formula cell is IGNORED** (`null`): the library does not evaluate it,
///   and the workbook's day/category totals are formulas the importer
///   recomputes itself (Appendix B.1);
/// * a text cell becomes its plain text.
///
/// Throws nothing it can avoid: a file the library cannot decode is reported as
/// `null` so the caller shows "this file cannot be read" instead of a crash.
List<RawSheet>? readWorkbook(Uint8List bytes) {
  try {
    final book = Excel.decodeBytes(bytes);
    return <RawSheet>[
      for (final entry in book.tables.entries)
        RawSheet(
          name: entry.key,
          rows: <List<Object?>>[
            for (final row in entry.value.rows)
              <Object?>[for (final cell in row) cellValueOf(cell)],
          ],
        ),
    ];
  } on Object {
    return null;
  }
}

/// One library cell -> the neutral value `RawSheet` documents.
Object? cellValueOf(Data? cell) => valueCell(cell?.value);

/// One library VALUE -> the neutral value `RawSheet` documents.
///
/// Split from [cellValueOf] so it can be tested without building the library's
/// `Data` wrapper, which has no public constructor.
Object? valueCell(CellValue? value) => switch (value) {
  null => null,
  FormulaCellValue() => null,
  TextCellValue(:final value) => _textOf(value),
  IntCellValue(:final value) => value.toString(),
  DoubleCellValue(:final value) => _decimal(value),
  BoolCellValue(:final value) => value.toString(),
  // The library documents `.year/.month/.day` on these two; the date part is
  // all the importer needs.
  DateCellValue(:final value) =>
    DateTime(value.year, value.month, value.day),
  DateTimeCellValue(:final value) =>
    DateTime(value.year, value.month, value.day),
  TimeCellValue() => null,
  _ => null,
};

String _textOf(Object value) {
  // `TextCellValue.value` is a `TextSpan`; its plain text is what a user sees.
  final plain = value is TextSpan ? value.text : value.toString();
  return (plain ?? '').trim();
}

/// `13.37` -> `"13.37"`, `2000.0` -> `"2000"`: a spreadsheet number without a
/// binary artefact and without a trailing `.0` that would confuse `Money.parse`.
String _decimal(double value) {
  if (value == value.roundToDouble() && value.abs() < 1e15) {
    return value.toInt().toString();
  }
  return value.toString();
}
