import 'package:family_hub/app/routing/app_routes.dart';
import 'package:family_hub/core/localization/generated/app_localizations.dart';
import 'package:family_hub/features/bazar/advances/presentation/screens/advances_screen.dart';
import 'package:family_hub/features/bazar/budgets/presentation/screens/budget_screen.dart';
import 'package:family_hub/features/bazar/expenses/presentation/screens/add_expense_screen.dart';
import 'package:family_hub/features/bazar/expenses/presentation/screens/bazar_trip_screen.dart';
import 'package:family_hub/features/bazar/expenses/presentation/screens/expense_detail_screen.dart';
import 'package:family_hub/features/bazar/expenses/presentation/screens/expense_list_screen.dart';
import 'package:family_hub/features/bazar/fund/presentation/screens/fund_screen.dart';
import 'package:family_hub/features/bazar/fund/presentation/screens/month_close_screen.dart';
import 'package:family_hub/features/bazar/items_categories/presentation/screens/catalog_manager_screen.dart';
import 'package:family_hub/features/bazar/presentation/bazar_home_screen.dart';
import 'package:family_hub/features/bazar/presentation/widgets/dashboard/budget_alert_card.dart';
import 'package:family_hub/features/bazar/presentation/widgets/dashboard/bazar_month_card.dart';
import 'package:family_hub/features/bazar/presentation/widgets/dashboard/fund_balance_card.dart';
import 'package:family_hub/features/bazar/presentation/widgets/dashboard/bazar_dashboard_cards.dart';
import 'package:family_hub/features/bazar/reports/presentation/screens/reports_screen.dart';
import 'package:family_hub/features/bazar/settings/presentation/screens/bazar_settings_screen.dart';
import 'package:family_hub/features/dashboard/domain/dashboard_card_spec.dart';
import 'package:family_hub/modules/family_module.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

/// The Bazar module.  The module switch is the gate, so
/// `requiredPermission` stays `null`.
class BazarModule extends FamilyModule {
  const BazarModule();

  @override
  String get id => 'bazar';

  @override
  String get nameBn => 'বাজার';

  @override
  String get nameEn => 'Bazar';

  @override
  String label(AppLocalizations l10n) => l10n.navBazar;

  @override
  IconData get icon => Icons.shopping_basket_outlined;

  @override
  IconData get selectedIcon => Icons.shopping_basket_rounded;

  @override
  String get basePath => AppRoutes.bazar;

  @override
  List<RouteBase> get routes => [
    GoRoute(
      path: AppRoutes.bazar,
      builder: (context, state) => const BazarHomeScreen(),
      routes: [
        // Declared before `expenses/:id`, which would otherwise match "new".
        GoRoute(
          path: 'expenses/new',
          builder: (context, state) => const AddExpenseScreen(),
        ),
        GoRoute(
          path: 'expenses',
          builder: (context, state) => const ExpenseListScreen(),
        ),
        GoRoute(
          path: 'expenses/:id',
          builder: (context, state) =>
              ExpenseDetailScreen(expenseId: state.pathParameters['id']!),
          routes: [
            GoRoute(
              path: 'edit',
              builder: (context, state) =>
                  AddExpenseScreen(editingId: state.pathParameters['id']),
            ),
          ],
        ),
        GoRoute(
          path: 'trip/new',
          builder: (context, state) => const BazarTripScreen(),
        ),
        GoRoute(
          path: 'catalog',
          builder: (context, state) => const CatalogManagerScreen(),
        ),
        GoRoute(
          path: 'budget',
          builder: (context, state) => const BudgetScreen(),
        ),
        GoRoute(
          path: 'fund',
          builder: (context, state) => FundScreen(
            focusPendingApprovals:
                state.uri.queryParameters['section'] == 'pending',
          ),
        ),
        GoRoute(
          path: 'advances',
          builder: (context, state) => const AdvancesScreen(),
        ),
        GoRoute(
          path: 'month-close',
          builder: (context, state) => const MonthCloseScreen(),
        ),
        GoRoute(
          path: 'reports',
          builder: (context, state) => const ReportsScreen(),
        ),
        GoRoute(
          path: 'settings',
          builder: (context, state) => const BazarSettingsScreen(),
        ),
      ],
    ),
  ];

  @override
  List<WidgetBuilder> get dashboardCards => bazarDashboardCards;

  @override
  List<DashboardCardSpec<DashboardCardBuilder>> get dashboardCardSpecs =>
      <DashboardCardSpec<DashboardCardBuilder>>[
        DashboardCardSpec<DashboardCardBuilder>(
          id: 'bazar_month',
          builder: (_, _) => const BazarMonthCard(),
        ),
        DashboardCardSpec<DashboardCardBuilder>(
          id: 'bazar_fund',
          builder: (_, _) => const FundBalanceCard(),
        ),
        DashboardCardSpec<DashboardCardBuilder>(
          id: 'budget_alert',
          builder: (_, _) => const BudgetAlertCard(),
        ),
      ];

  @override
  List<String> get reports => const ['bazar_month', 'bazar_categories'];
}
